import java.util.Scanner;

interface HockeyTeam {
    public int calculateHockeyScore();
    public int findHighestGoalByIndividualInHockey();
}

interface FootballTeam {
    public int calculateFootballScore();
    public int findHighestGoalByIndividualInFootball();
}

public class Sport implements HockeyTeam, FootballTeam {

    int[] hockeyPlayers;
    int[] footballPlayers;

    public Sport(int[] paramHockeyPlayers, int[] paramFootballPlayers) {
        // Ensure only first 11 from paramHockeyPlayers and last 11 from paramFootballPlayers
        hockeyPlayers = new int[11];
        footballPlayers = new int[11];
        for (int i = 0; i < 11; i++) {
            hockeyPlayers[i] = paramHockeyPlayers[i];
            footballPlayers[i] = paramFootballPlayers[i];
        }
    }

    @Override
    public int calculateHockeyScore() {
        int sum = 0;
        for (int score : hockeyPlayers) {
            sum += score;
        }
        return sum;
    }

    @Override
    public int findHighestGoalByIndividualInHockey() {
        int max = hockeyPlayers[0];
        for (int score : hockeyPlayers) {
            if (score > max) {
                max = score;
            }
        }
        return max;
    }

    @Override
    public int calculateFootballScore() {
        int sum = 0;
        for (int score : footballPlayers) {
            sum += score;
        }
        return sum;
    }

    @Override
    public int findHighestGoalByIndividualInFootball() {
        int max = footballPlayers[0];
        for (int score : footballPlayers) {
            if (score > max) {
                max = score;
            }
        }
        return max;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] hockeyInput = new int[11];
        int[] footballInput = new int[11];

        // Read hockey scores
        for (int i = 0; i < 11; i++) {
            hockeyInput[i] = sc.nextInt();
        }

        // Read football scores
        for (int i = 0; i < 11; i++) {
            footballInput[i] = sc.nextInt();
        }

        Sport sport = new Sport(hockeyInput, footballInput);

        System.out.println(sport.calculateHockeyScore());
        System.out.println(sport.calculateFootballScore());
        System.out.println(sport.findHighestGoalByIndividualInHockey());
        System.out.println(sport.findHighestGoalByIndividualInFootball());
    }
}
