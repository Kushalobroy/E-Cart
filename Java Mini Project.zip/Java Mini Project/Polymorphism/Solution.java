import java.util.Scanner;

class Parent {
    public int startElement;
    public int endElement;

    String filter() {
        return null;
    }
}

class ChildOne extends Parent {

    @Override
    String filter() {
        StringBuilder primes = new StringBuilder();
        for (int i = startElement; i <= endElement; i++) {
            if (isPrime(i)) {
                primes.append(i).append(" ");
            }
        }
        return primes.toString().trim();
    }

    private boolean isPrime(int n) {
        if (n < 2) return false;
        if (n == 2) return true;
        if (n % 2 == 0) return false;
        for (int i = 3; i <= Math.sqrt(n); i += 2) {
            if (n % i == 0) return false;
        }
        return true;
    }
}

class ChildTwo extends Parent {

    @Override
    String filter() {
        StringBuilder happyNumbers = new StringBuilder();
        for (int i = startElement; i <= endElement; i++) {
            if (isHappy(i)) {
                happyNumbers.append(i).append(" ");
            }
        }
        return happyNumbers.toString().trim();
    }

    private boolean isHappy(int n) {
        int slow = n;
        int fast = n;

        do {
            slow = sumOfSquares(slow);
            fast = sumOfSquares(sumOfSquares(fast));
        } while (slow != fast);

        return slow == 1;
    }

    private int sumOfSquares(int n) {
        int sum = 0;
        while (n > 0) {
            int d = n % 10;
            sum += d * d;
            n /= 10;
        }
        return sum;
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int start = sc.nextInt();
        int end = sc.nextInt();

        ChildOne childOne = new ChildOne();
        childOne.startElement = start;
        childOne.endElement = end;
        System.out.println(childOne.filter());

        ChildTwo childTwo = new ChildTwo();
        childTwo.startElement = start;
        childTwo.endElement = end;
        System.out.println(childTwo.filter());

        sc.close();
    }
}
