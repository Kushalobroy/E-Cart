import java.sql.*;
import java.util.ArrayList;

public class DbOperations {

    public boolean insertCategory(String type) {
        String query = "INSERT INTO Category (type) VALUES (?)";
        try (Connection conn = DbUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, type);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public ArrayList<Object> getCategoryById(int id) {
        ArrayList<Object> list = new ArrayList<>();
        String query = "SELECT * FROM Category WHERE id=?";
        try (Connection conn = DbUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                list.add(rs.getInt("id"));
                list.add(rs.getString("type"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public ResultSet getAllCategory() throws SQLException {
        Connection conn = DbUtil.getConnection();
        String query = "SELECT * FROM Category";
        PreparedStatement ps = conn.prepareStatement(query);
        return ps.executeQuery();
    }

    public boolean insertProduct(String name, float price, String type) {
        String getCategoryId = "SELECT id FROM Category WHERE type=?";
        String insertProduct = "INSERT INTO Product (name, price, category_id) VALUES (?, ?, ?)";
        try (Connection conn = DbUtil.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps1 = conn.prepareStatement(getCategoryId)) {
                ps1.setString(1, type);
                ResultSet rs = ps1.executeQuery();
                if (rs.next()) {
                    int categoryId = rs.getInt("id");

                    try (PreparedStatement ps2 = conn.prepareStatement(insertProduct)) {
                        ps2.setString(1, name);
                        ps2.setFloat(2, price);
                        ps2.setInt(3, categoryId);
                        boolean success = ps2.executeUpdate() > 0;
                        conn.commit();
                        return success;
                    }
                } else {
                    System.out.println("Category type not found.");
                    conn.rollback();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public ArrayList<Object> getProductById(int id) {
        ArrayList<Object> list = new ArrayList<>();
        String query = "SELECT * FROM Product WHERE id=?";
        try (Connection conn = DbUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                list.add(rs.getInt("id"));
                list.add(rs.getString("name"));
                list.add(rs.getFloat("price"));
                list.add(rs.getInt("category_id"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public ResultSet getAllProduct() throws SQLException {
        Connection conn = DbUtil.getConnection();
        String query = "SELECT * FROM Product";
        PreparedStatement ps = conn.prepareStatement(query);
        return ps.executeQuery();
    }

    public boolean insertOrder(String product_name, Date date) {
        String getProductId = "SELECT id FROM Product WHERE name=?";
        String insertOrder = "INSERT INTO Orders (product_id, order_date) VALUES (?, ?)";
        try (Connection conn = DbUtil.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps1 = conn.prepareStatement(getProductId)) {
                ps1.setString(1, product_name);
                ResultSet rs = ps1.executeQuery();
                if (rs.next()) {
                    int productId = rs.getInt("id");

                    try (PreparedStatement ps2 = conn.prepareStatement(insertOrder)) {
                        ps2.setInt(1, productId);
                        ps2.setDate(2, date);
                        boolean success = ps2.executeUpdate() > 0;
                        conn.commit();
                        return success;
                    }
                } else {
                    System.out.println("Product not found.");
                    conn.rollback();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public ArrayList<Object> getOrderById(int id) {
        ArrayList<Object> list = new ArrayList<>();
        String query = "SELECT * FROM Orders WHERE id=?";
        try (Connection conn = DbUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                list.add(rs.getInt("id"));
                list.add(rs.getInt("product_id"));
                list.add(rs.getDate("order_date"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public ResultSet getAllOrder() throws SQLException {
        Connection conn = DbUtil.getConnection();
        String query = "SELECT * FROM Orders";
        PreparedStatement ps = conn.prepareStatement(query);
        return ps.executeQuery();
    }
}
