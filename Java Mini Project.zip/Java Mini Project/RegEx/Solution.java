package com.fresco;

import java.util.regex.*;
import java.util.*;

public class RegEx {

    public String findCardTypeNumbers(String conversation, String cardType) {
        Set<String> validCardTypes = new HashSet<>(Arrays.asList(
            "Visa", "American Express", "Discover", "JCB"
        ));

        if (!validCardTypes.contains(cardType)) {
            return "Not a valid card type";
        }

        Pattern numberPattern = Pattern.compile("\\d+");
        Matcher numberMatcher = numberPattern.matcher(conversation);

        List<String> matches = new ArrayList<>();

        while (numberMatcher.find()) {
            String number = numberMatcher.group();

            if (matchesCardType(number, cardType)) {
                matches.add(number);
            }
        }

        return String.join(" ", matches);
    }

    private boolean matchesCardType(String number, String cardType) {
        switch (cardType) {
            case "Visa":
                return (number.startsWith("4") && (number.length() == 13 || number.length() == 16));
            
            case "American Express":
                return (number.startsWith("34") || number.startsWith("37")) && number.length() == 15;
            
            case "Discover":
                return ((number.startsWith("6011") || number.startsWith("65")) && number.length() == 16);
            
            case "JCB":
                if ((number.startsWith("2131") || number.startsWith("1800")) && number.length() == 15) {
                    return true;
                }
                if (number.startsWith("35") && number.length() == 16) {
                    return true;
                }
                return false;

            default:
                return false;
        }
    }
}
